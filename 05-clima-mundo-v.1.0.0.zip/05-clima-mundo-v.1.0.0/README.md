## Aplicación del cliente - curso node

Recuerden ejecutar ```npm install ``` para las librerias

### Ejemplo:
```
node app -d "San Jose Costa Rica"
```